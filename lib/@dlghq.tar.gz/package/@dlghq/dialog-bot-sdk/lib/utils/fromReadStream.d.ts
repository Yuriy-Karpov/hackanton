/// <reference types="node" />
import { ReadStream } from 'fs';
import { Observable } from 'rxjs';
declare function fromReadStream(stream: ReadStream): Observable<Buffer>;
export default fromReadStream;
