declare function mapNotNull<T, R>(collection: Array<T>, mapper: (value: T) => R | null | undefined): Array<R>;
export default mapNotNull;
