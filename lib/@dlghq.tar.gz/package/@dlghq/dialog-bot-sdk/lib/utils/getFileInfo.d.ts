export declare type FileInfo = {
    name: string;
    size: number;
    mime: string;
};
/**
 * @private
 * @returns file size in bytes
 */
declare function getFileInfo(fileName: string): Promise<FileInfo>;
export default getFileInfo;
