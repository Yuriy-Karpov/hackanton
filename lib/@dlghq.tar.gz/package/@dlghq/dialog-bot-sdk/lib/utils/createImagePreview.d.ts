import { FilePreview, DocumentPhotoExtension } from '../entities';
/**
 * @private
 */
declare function createImagePreview(fileName: string): Promise<{
    extension: DocumentPhotoExtension;
    preview: FilePreview;
}>;
export default createImagePreview;
