declare function randomLong(): Promise<any>;
export default randomLong;
