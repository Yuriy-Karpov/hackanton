import Record from 'dataclass';
import { dialog } from '@dlghq/dialog-api';
declare class FullUser extends Record<FullUser> {
    id: number;
    about: string | null;
    preferredLanguages: Array<string>;
    timeZone: string | null;
    isBlocked: boolean;
    customProfile: string | null;
    static from(api: dialog.FullUser): FullUser;
    toString(): string;
}
export default FullUser;
