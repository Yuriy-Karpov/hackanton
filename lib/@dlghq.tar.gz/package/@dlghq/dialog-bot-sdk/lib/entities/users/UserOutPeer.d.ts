import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
declare class UserOutPeer {
    readonly id: number;
    readonly accessHash: Long;
    static from(api: dialog.UserOutPeer): UserOutPeer;
    static create(id: number, accessHash: Long): UserOutPeer;
    private constructor();
    toApi(): dialog.UserOutPeer;
    toString(): string;
}
export default UserOutPeer;
