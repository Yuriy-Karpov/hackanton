import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
declare class GroupOutPeer {
    readonly id: number;
    readonly accessHash: Long;
    static from(api: dialog.GroupOutPeer): GroupOutPeer;
    static create(id: number, accessHash: Long): GroupOutPeer;
    private constructor();
    toApi(): dialog.GroupOutPeer;
    toString(): string;
}
export default GroupOutPeer;
