import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
import GroupData from './GroupData';
import GroupOutPeer from './GroupOutPeer';
import Peer from '../Peer';
declare class Group {
    readonly id: number;
    readonly data: GroupData | null;
    readonly accessHash: Long;
    static from(api: dialog.Group): Group;
    constructor(id: number, data: GroupData | null, accessHash: Long);
    getPeer(): Peer;
    getGroupOutPeer(): GroupOutPeer;
}
export default Group;
