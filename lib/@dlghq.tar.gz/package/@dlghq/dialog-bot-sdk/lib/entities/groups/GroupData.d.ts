import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
import UUID from '../UUID';
import Avatar from '../Avatar';
import { GroupType } from './GroupType';
declare class GroupData {
    readonly clock: Long;
    readonly type: GroupType;
    readonly spaceId: null | UUID;
    readonly ownerId: number;
    readonly title: string;
    readonly avatar: null | Avatar;
    readonly createdAt: Date;
    readonly about?: null | string;
    readonly membersAmount: number;
    static from(api: dialog.GroupData): GroupData;
    constructor(api: dialog.GroupData);
}
export default GroupData;
