import { dialog } from '@dlghq/dialog-api';
declare enum GroupPermission {
    UNKNOWN = 0,
    EDIT_SHORTNAME = 1,
    INVITE = 2,
    KICK = 3,
    UPDATE_INFO = 4,
    SET_PERMISSIONS = 5,
    EDIT_MESSAGE = 6,
    DELETE_MESSAGE = 7,
    GET_INTEGRATION_TOKEN = 8,
    SEND_MESSAGE = 9,
    PIN_MESSAGE = 10,
    VIEW_MEMBERS = 11
}
export declare function groupPermissionFromApi(type: dialog.GroupAdminPermission): GroupPermission;
export default GroupPermission;
