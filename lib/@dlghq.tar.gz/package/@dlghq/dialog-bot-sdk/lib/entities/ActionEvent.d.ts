import { dialog } from '@dlghq/dialog-api';
import UUID from './UUID';
declare class ActionEvent {
    readonly id: string;
    readonly value: string;
    readonly uid: number;
    readonly mid: null | UUID;
    static from(api: dialog.UpdateInteractiveMediaEvent): ActionEvent;
    private constructor();
}
export default ActionEvent;
