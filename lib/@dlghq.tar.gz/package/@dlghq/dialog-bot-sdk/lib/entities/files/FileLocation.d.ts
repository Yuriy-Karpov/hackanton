import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
declare class FileLocation {
    readonly id: Long;
    readonly accessHash: Long;
    static from(api: dialog.FileLocation): FileLocation;
    static create(id: Long, accessHash: Long): FileLocation;
    protected constructor(id: Long, accessHash: Long);
    toApi(): dialog.FileLocation;
    toString(): string;
}
export default FileLocation;
