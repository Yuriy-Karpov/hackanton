import { dialog } from '@dlghq/dialog-api';
declare class FilePreview {
    /**
     * Preview width.
     */
    private readonly width;
    /**
     * Preview height;
     */
    private readonly height;
    /**
     * Preview content in PNG format.
     */
    private readonly content;
    static from(api: dialog.FastThumb): FilePreview;
    static create(width: number, height: number, content: Uint8Array): FilePreview;
    private constructor();
    toApi(): dialog.FastThumb;
}
export default FilePreview;
