import { dialog } from '@dlghq/dialog-api';
import FileLocation from './files/FileLocation';
declare class AvatarImage {
    readonly width: number;
    readonly height: number;
    readonly size: number;
    readonly location: null | FileLocation;
    constructor(api: dialog.AvatarImage);
    toApi(): dialog.AvatarImage;
    toString(): string;
}
export default AvatarImage;
