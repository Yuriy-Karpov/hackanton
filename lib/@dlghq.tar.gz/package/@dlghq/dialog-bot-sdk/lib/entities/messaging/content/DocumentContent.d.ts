import { dialog } from '@dlghq/dialog-api';
import FileLocation from '../../files/FileLocation';
import FilePreview from '../../files/FilePreview';
import { DocumentExtension } from './document';
declare class DocumentContent {
    readonly type = "document";
    readonly name: string;
    readonly size: number;
    readonly mime: string;
    readonly preview: null | FilePreview;
    readonly location: FileLocation;
    readonly extension: null | DocumentExtension;
    static from(api: dialog.DocumentMessage): DocumentContent;
    static create(name: string, size: number, mime: string, preview: null | FilePreview, location: FileLocation, extension: null | DocumentExtension): DocumentContent;
    private constructor();
    toApi(): dialog.MessageContent;
}
export default DocumentContent;
