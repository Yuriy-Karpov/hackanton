import { dialog } from '@dlghq/dialog-api';
declare class ServiceContent {
    readonly text: string;
    readonly extension: null | dialog.ServiceEx;
    readonly type = "service";
    static from(api: dialog.ServiceMessage): ServiceContent;
    constructor(text: string, extension: null | dialog.ServiceEx);
}
export default ServiceContent;
