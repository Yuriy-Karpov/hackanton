import { dialog } from '@dlghq/dialog-api';
import TextContent from './TextContent';
import ServiceContent from './ServiceContent';
import DocumentContent from './DocumentContent';
import DeletedContent from './DeletedContent';
import UnknownContent from './UnknownContent';
export declare type Content = TextContent | ServiceContent | DocumentContent | DeletedContent | UnknownContent;
export { TextContent, ServiceContent, DocumentContent, DeletedContent, UnknownContent };
export * from './document';
/**
 * @private
 */
export declare function apiToContent(api: dialog.MessageContent): Content;
/**
 * @private
 */
export declare function contentToApi(content: Content): dialog.MessageContent;
