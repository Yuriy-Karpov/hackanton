import { dialog } from '@dlghq/dialog-api';
import Peer from '../Peer';
import UUID from '../UUID';
import { Content } from './content';
import MessageAttachment from './MessageAttachment';
declare class Message {
    /**
     * The message id.
     */
    readonly id: UUID;
    /**
     * The peer of the chat which contains message.
     */
    readonly peer: Peer;
    /**
     * The message date.
     */
    readonly date: Date;
    /**
     * The message content.
     */
    readonly content: Content;
    /**
     * The message attachment.
     */
    readonly attachment: null | MessageAttachment;
    /**
     * The id of the user who sent the message.
     */
    readonly senderUserId: number;
    static from(api: dialog.UpdateMessage): Message;
    constructor(id: UUID, peer: Peer, date: Date, content: Content, attachment: null | MessageAttachment, senderUserId: number);
}
export default Message;
