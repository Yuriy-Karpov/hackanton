import { dialog } from '@dlghq/dialog-api';
declare type Props = {
    label: string;
    value?: string;
};
declare class Button {
    readonly label: string;
    readonly value: string;
    static from(api: dialog.InteractiveMediaButton): Button;
    static create({ label, value }: Props): Button;
    private constructor();
    toApi(): dialog.InteractiveMediaWidget;
}
export default Button;
