import { dialog } from '@dlghq/dialog-api';
import Button from './Button';
import Select from './Select';
import SelectOption from './SelectOption';
export declare type Widget = Button | Select;
export { Button, Select, SelectOption };
/**
 * @private
 */
export declare function apiToWidget(api: dialog.InteractiveMediaWidget): null | Widget;
