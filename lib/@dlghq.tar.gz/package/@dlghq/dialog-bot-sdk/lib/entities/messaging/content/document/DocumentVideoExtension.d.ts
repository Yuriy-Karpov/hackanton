import { dialog } from '@dlghq/dialog-api';
declare class DocumentVideoExtension {
    readonly type = "video";
    readonly width: number;
    readonly height: number;
    readonly duration: number;
    static from(api: dialog.DocumentExVideo): DocumentVideoExtension;
    private constructor();
    toApi(): dialog.DocumentEx;
}
export default DocumentVideoExtension;
