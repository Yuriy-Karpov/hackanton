import { dialog } from '@dlghq/dialog-api';
declare type Props = {
    text: null | string;
    title?: null | string;
    ok?: null | string;
    dismiss?: null | string;
};
declare class ActionConfirm {
    readonly text: null | string;
    readonly title: null | string;
    readonly ok: null | string;
    readonly dismiss: null | string;
    static from(api: dialog.InteractiveMediaConfirm): ActionConfirm;
    static create({ text, title, ok, dismiss }: Props): ActionConfirm;
    private constructor();
    toApi(): dialog.InteractiveMediaConfirm;
}
export default ActionConfirm;
