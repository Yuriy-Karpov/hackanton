import { dialog } from '@dlghq/dialog-api';
import ActionGroup from '../interactive/ActionGroup';
declare class TextContent {
    readonly text: string;
    readonly actions: Array<ActionGroup>;
    readonly type = "text";
    static from(api: dialog.TextMessage): TextContent;
    static create(text: string, actions: Array<ActionGroup>): TextContent;
    private constructor();
    toApi(): dialog.MessageContent;
}
export default TextContent;
