declare class MessageAction {
}
export default MessageAction;
