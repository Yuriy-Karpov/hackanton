import Peer from './Peer';
declare class PeerMap<T> {
    private readonly sips;
    private readonly groups;
    private readonly privates;
    clear(): void;
    delete(peer: Peer): boolean;
    forEach(iterator: (value: T, peer: Peer) => void): void;
    get(peer: Peer): T | undefined;
    has(peer: Peer): boolean;
    set(peer: Peer, value: T): this;
}
export default PeerMap;
