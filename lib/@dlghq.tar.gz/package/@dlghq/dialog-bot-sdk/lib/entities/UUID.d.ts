import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
declare class UUID {
    private readonly msb;
    private readonly lsb;
    static from(api: dialog.UUIDValue): UUID;
    constructor(msb: Long, lsb: Long);
    toApi(): dialog.UUIDValue;
    toString(): string;
    toJSON(): string;
}
export default UUID;
