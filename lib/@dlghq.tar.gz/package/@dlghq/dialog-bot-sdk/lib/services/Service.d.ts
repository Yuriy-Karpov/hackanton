import { Logger } from 'pino';
import { Metadata, CallOptions, ChannelCredentials, Client } from 'grpc';
export declare type MetadataGenerator = (serviceUrl: string) => Promise<Metadata>;
export declare type Config = {
    logger: Logger;
    endpoint: string;
    credentials: ChannelCredentials;
    generateMetadata: MetadataGenerator;
};
declare type CallOptionsConfig = {
    deadline?: number;
    authRequired?: boolean;
};
declare abstract class Service<T extends Client> {
    protected readonly service: T;
    private readonly credentials;
    private readonly noopCredentials;
    protected constructor(ServiceImpl: T, config: Config);
    protected getCallOptions({ deadline, authRequired, }?: CallOptionsConfig): CallOptions;
    close(): void;
}
export default Service;
