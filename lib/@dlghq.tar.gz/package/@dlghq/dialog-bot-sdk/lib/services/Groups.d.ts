import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Groups extends Service<any> {
    constructor(config: Config);
    loadMembers(request: dialog.RequestLoadMembers, metadata?: Metadata): Promise<dialog.ResponseLoadMembers>;
    createGroup(request: dialog.RequestCreateGroup, metadata?: Metadata): Promise<dialog.ResponseCreateGroup>;
    editGroupTitle(request: dialog.RequestEditGroupTitle, metadata?: Metadata): Promise<dialog.ResponseSeqDateMid>;
    editGroupAbout(request: dialog.RequestEditGroupAbout, metadata?: Metadata): Promise<dialog.ResponseSeqDate>;
    inviteUser(request: dialog.RequestInviteUser, metadata?: Metadata): Promise<dialog.ResponseSeqDateMid>;
    leaveGroup(request: dialog.RequestLeaveGroup, metadata?: Metadata): Promise<dialog.ResponseSeqDateMid>;
    kickUser(request: dialog.RequestKickUser, metadata?: Metadata): Promise<dialog.ResponseSeqDateMid>;
    getGroupInviteUrl(request: dialog.RequestGetGroupInviteUrl, metadata?: Metadata): Promise<dialog.ResponseInviteUrl>;
    joinGroup(request: dialog.RequestJoinGroup, metadata?: Metadata): Promise<dialog.ResponseJoinGroup>;
}
export default Groups;
