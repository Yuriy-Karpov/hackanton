import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Parameters extends Service<any> {
    constructor(config: Config);
    getParameters(request: dialog.RequestGetParameters, metadata?: Metadata): Promise<dialog.ResponseGetParameters>;
    editParameter(request: dialog.RequestEditParameter, metadata?: Metadata): Promise<dialog.ResponseSeq>;
}
export default Parameters;
