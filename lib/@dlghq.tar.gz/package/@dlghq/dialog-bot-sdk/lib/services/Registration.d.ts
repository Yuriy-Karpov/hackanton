import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Registration extends Service<any> {
    constructor(config: Config);
    registerDevice(request: dialog.RequestRegisterDevice, metadata?: Metadata): Promise<dialog.ResponseDeviceRequest>;
}
export default Registration;
