/// <reference types="node" />
import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class MediaAndFiles extends Service<any> {
    constructor(config: Config);
    getFileUrls(request: dialog.RequestGetFileUrls, metadata?: Metadata): Promise<dialog.ResponseGetFileUrls>;
    getFileUploadUrl(request: dialog.RequestGetFileUploadUrl, metadata?: Metadata): Promise<dialog.ResponseGetFileUploadUrl>;
    getFileUploadPartUrl(request: dialog.RequestGetFileUploadPartUrl, metadata?: Metadata): Promise<dialog.ResponseGetFileUploadPartUrl>;
    commitFileUpload(request: dialog.RequestCommitFileUpload, metadata?: Metadata): Promise<dialog.ResponseCommitFileUpload>;
    uploadChunk(url: string, content: Buffer): Promise<void>;
}
export default MediaAndFiles;
