import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Search extends Service<any> {
    constructor(config: Config);
    resolvePeer(request: dialog.RequestResolvePeer, metadata?: Metadata): Promise<dialog.ResponseResolvePeer>;
}
export default Search;
