import { Logger, LoggerOptions } from 'pino';
import { Observable, Subject } from 'rxjs';
import { dialog } from '@dlghq/dialog-api';
import { Token } from './Rpc';
import { UUID, Peer, User, Group, GroupMemberList, ActionEvent, FileLocation, Message, HistoryMessage, ActionGroup, MessageAttachment, FullUser, HistoryListMode, GroupType } from './entities';
import { SSLConfig } from './utils/createCredentials';
declare type Config = {
    token: Token;
    endpoints: Array<string>;
    ssl?: SSLConfig;
    loggerOptions?: LoggerOptions;
};
declare class Bot {
    private readonly rpc;
    private readonly ready;
    private subscriptions;
    readonly logger: Logger;
    readonly updateSubject: Subject<dialog.UpdateSeqUpdate>;
    constructor(config: Config);
    stop(): void;
    private start;
    private applyEntities;
    /**
     * Returns self (bot) user entity.
     */
    getSelf(): Promise<User>;
    /**
     * Returns user by id, if bot already seen this user before.
     * Returns null if user not found.
     */
    getUser(userId: number): Promise<null | User>;
    /**
     * Returns user by id, if bot already seen this user before.
     * Throws PeerNotFoundError if user not found.
     */
    forceGetUser(userId: number): Promise<User>;
    /**
     * Loads full user profile, if bot already seen this user before.
     */
    loadFullUser(userId: number): Promise<FullUser | null>;
    /**
     * Returns group by id, if bot already seen this group before.
     * Returns null if group not found.
     */
    getGroup(gid: number): Promise<null | Group>;
    /**
     * Returns group by id, if bot already seen this group before.
     * Throws PeerNotFoundError if group not found.
     */
    forceGetGroup(groupId: number): Promise<Group>;
    /**
     * Returns existing dialogs.
     */
    getDialogs(): Promise<Array<Peer>>;
    /**
     * Returns existing dialogs.
     */
    getGroupMembers(groupId: number): Promise<GroupMemberList | null>;
    /**
     * Subscribes to messages stream.
     */
    subscribeToMessages(): Observable<Message>;
    /**
     * Subscribes to messages stream.
     */
    subscribeToActions(): Observable<ActionEvent>;
    /**
     * Sends text message.
     */
    sendText(peer: Peer, text: string, attachment?: null | MessageAttachment, actionOrActions?: ActionGroup | ActionGroup[]): Promise<UUID>;
    /**
     * Edits text message.
     */
    editText(mid: UUID, text: string, actionOrActions?: ActionGroup | ActionGroup[]): Promise<void>;
    /**
     * Reads all messages before `since`.
     */
    readMessages(peer: Peer, since: Message): Promise<void>;
    /**
     * Edits text message.
     */
    deleteMessage(mid: UUID): Promise<void>;
    /**
     * Sends document message.
     */
    sendDocument(peer: Peer, fileName: string, attachment?: MessageAttachment): Promise<UUID>;
    /**
     * Sends image message.
     */
    sendImage(peer: Peer, fileName: string, attachment?: MessageAttachment): Promise<UUID>;
    /**
     * Retrieves file url by location.
     */
    fetchFileUrl(fileLocation: FileLocation): Promise<string>;
    /**
     * Retrieves messages by message ids.
     */
    fetchMessages(mids: Array<UUID>): Promise<Array<HistoryMessage>>;
    /**
     * Loads chat history.
     */
    loadHistory(peer: Peer, since?: Message | null, limit?: number, direction?: HistoryListMode): Promise<Array<HistoryMessage>>;
    /**
     * Returns the parameter from key-value synced with the server.
     */
    getParameter(key: string): Promise<string | null>;
    /**
     * Sets the parameter from key-value synced with the server.
     */
    setParameter(key: string, value: string): Promise<void>;
    /**
     * Creates new group or channel.
     */
    createGroup(title: string, type: GroupType): Promise<Group>;
    /**
     * Leaves the group.
     */
    leaveGroup(group: Group): Promise<void>;
    /**
     * Edits a group title.
     */
    editGroupTitle(group: Group, title: string): Promise<void>;
    /**
     * Edits a group about (description).
     */
    editGroupAbout(group: Group, about: string | null): Promise<void>;
    /**
     * Invites a user to the group.
     */
    inviteGroupMember(group: Group, user: User): Promise<void>;
    /**
     * Kicks the member from the group.
     */
    kickGroupMember(group: Group, user: User): Promise<void>;
    /**
     * Fetches the group invite URL.
     */
    fetchGroupInviteUrl(group: Group): Promise<string>;
    /**
     * Joins the group by invite token.
     */
    joinGroupByToken(token: string): Promise<Group>;
    /**
     * Finds peer by username or shortname.
     */
    findPeer(nickOrShortName: string): Promise<Peer | null>;
    /**
     * Finds group by shortname.
     */
    findUserByNick(nick: string): Promise<User | null>;
    /**
     * Finds group by shortname.
     */
    findGroupByShortname(shortname: string): Promise<Group | null>;
}
export default Bot;
