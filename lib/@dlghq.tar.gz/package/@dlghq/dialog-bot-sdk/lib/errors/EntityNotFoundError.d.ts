declare class EntityNotFoundError<ID> extends Error {
    readonly name = "EntityNotFound";
    readonly id: ID;
    constructor(id: ID);
}
export default EntityNotFoundError;
