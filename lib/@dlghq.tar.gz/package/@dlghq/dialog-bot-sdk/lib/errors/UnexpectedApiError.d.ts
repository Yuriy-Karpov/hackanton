declare class UnexpectedApiError extends Error {
    readonly name = "UnexpectedApiError";
    constructor(field: string);
}
export default UnexpectedApiError;
