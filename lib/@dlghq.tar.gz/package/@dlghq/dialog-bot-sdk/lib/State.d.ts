import { dialog } from '@dlghq/dialog-api';
import { Group, OutPeer, Peer, User, GroupOutPeer, GroupMember, GroupMemberList } from './entities';
import { Entities, PeerEntities, ResponseEntities } from './internal/types';
declare class State {
    readonly self: User;
    readonly users: Map<number, User>;
    readonly groups: Map<number, Group>;
    readonly groupMembers: Map<number, GroupMemberList>;
    readonly dialogs: Array<Peer>;
    readonly parameters: Map<string, string>;
    constructor(self: User);
    createOutPeer(peer: Peer): OutPeer;
    createGroupOutPeer(groupId: number): GroupOutPeer;
    applyDialogs(dialogs: dialog.Dialog[]): void;
    applyEntities({ users, groups }: Entities): void;
    applyGroupMembers(groupId: number, members: Array<GroupMember>): void;
    applyResponseEntities({ peers, users, groups, userPeers, groupPeers, groupMembersSubset, }: ResponseEntities<any>): PeerEntities;
    private hasPeer;
    applyParameters(parameters: Map<string, string>): void;
    checkEntities(update: dialog.UpdateSeqUpdate): Array<dialog.Peer>;
    applyUpdate(update: dialog.UpdateSeqUpdate): void;
    private handleParameterChanged;
}
export default State;
