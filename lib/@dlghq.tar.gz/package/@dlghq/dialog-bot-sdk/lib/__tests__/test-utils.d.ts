declare type ContextCallback<T> = (context: T) => Promise<void>;
export declare function beforeAllWithContext<T>(callback: () => Promise<T>): Promise<T>;
export declare function afterAllWithContext<T>(context: Promise<T>, callback: ContextCallback<T>): void;
export declare function beforeEachWithContext<T>(callback: () => Promise<T>): Promise<T>;
export declare function afterEachWithContext<T>(context: Promise<T>, callback: ContextCallback<T>): void;
export declare function describeWithContext<T>(name: string, context: Promise<T>, fn: ContextCallback<T>): void;
export declare function itWithContext<T>(name: string, context: Promise<T>, fn: ContextCallback<T>): void;
export declare function testWithContext<T>(name: string, context: Promise<T>, fn: ContextCallback<T>): void;
export {};
