import Bot, { Peer } from '../index';
declare const context: Promise<{
    bot1: Bot;
    bot2: Bot;
    bot2Peer: Peer;
}>;
export default context;
