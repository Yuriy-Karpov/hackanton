/*
 * Copyright 2018 Dialog LLC <info@dlg.im>
 */

import Bot from './Bot';

export * from './entities';

export default Bot;
