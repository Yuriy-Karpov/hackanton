/*
 * Copyright 2018 Dialog LLC <info@dlg.im>
 */

import FilePreview from './FilePreview';
import FileLocation from './FileLocation';

export {
  FilePreview,
  FileLocation
};
