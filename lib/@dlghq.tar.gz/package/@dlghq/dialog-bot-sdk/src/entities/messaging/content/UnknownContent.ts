/*
 * Copyright 2018 Dialog LLC <info@dlg.im>
 */

class UnknownContent {
  public readonly type = 'unknown';

  public static create() {
    return new UnknownContent();
  }
}

export default UnknownContent;
