import { Peer } from '../entities';
import EntityNotFoundError from './EntityNotFoundError';
declare class PeerNotFoundError extends EntityNotFoundError<Peer> {
    constructor(peer: Peer);
}
export default PeerNotFoundError;
