import { dialog } from '@dlghq/dialog-api';
export declare type Entities = {
    users: Array<dialog.User>;
    groups: Array<dialog.Group>;
};
export declare type PeerEntities = {
    users: Array<dialog.UserOutPeer>;
    groups: Array<dialog.GroupOutPeer>;
    groupMembersSubset?: dialog.GroupMembersSubset;
};
export declare type ResponseEntities<T> = {
    payload: T;
    users?: Array<dialog.User>;
    groups?: Array<dialog.Group>;
    peers?: Array<dialog.OutPeer>;
    userPeers?: Array<dialog.UserOutPeer>;
    groupPeers?: Array<dialog.GroupOutPeer>;
    groupMembersSubset?: dialog.GroupMembersSubset;
};
