import { dialog } from '@dlghq/dialog-api';
import AvatarImage from './AvatarImage';
declare class Avatar {
    readonly full: null | AvatarImage;
    readonly small: null | AvatarImage;
    readonly large: null | AvatarImage;
    constructor(api: dialog.Avatar);
    toApi(): dialog.Avatar;
    toString(): string;
}
export default Avatar;
