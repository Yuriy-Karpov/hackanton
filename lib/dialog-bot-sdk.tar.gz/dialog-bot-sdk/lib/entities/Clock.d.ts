import Long from 'long';
declare class Clock {
    readonly value: Long;
    static from(value: Long): Clock;
    constructor(value: Long);
    toJSON(): string;
    toString(): string;
}
export default Clock;
