import { dialog } from '@dlghq/dialog-api/js';
declare enum HistoryListMode {
    UNKNOWN = "unknown",
    FORWARD = "forward",
    BACKWARD = "backward",
    BOTH = "both"
}
export declare function historyListModeToApi(type: HistoryListMode): dialog.ListLoadMode;
export default HistoryListMode;
