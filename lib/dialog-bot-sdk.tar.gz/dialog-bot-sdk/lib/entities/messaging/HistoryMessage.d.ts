import { dialog } from '@dlghq/dialog-api';
import UUID from '../UUID';
import { Content } from './content';
import MessageAttachment from './MessageAttachment';
import OutPeer from '../OutPeer';
declare class HistoryMessage {
    readonly id: UUID;
    readonly peer: null | OutPeer;
    readonly senderUserId: number;
    readonly senderPeer: null | OutPeer;
    readonly date: Date;
    readonly content: Content;
    readonly attachment: null | MessageAttachment;
    static from(api: dialog.HistoryMessage): HistoryMessage;
    constructor(id: UUID, peer: null | OutPeer, senderUserId: number, senderPeer: null | OutPeer, date: Date, content: Content, attachment: null | MessageAttachment);
}
export default HistoryMessage;
