import { dialog } from '@dlghq/dialog-api';
import Action from './Action';
declare type Props = {
    actions: Array<Action>;
    title?: null | string;
    description?: null | string;
    translations?: null | Translations;
};
declare type Translations = {
    [locale: string]: {
        [key: string]: string;
    };
};
declare class ActionGroup {
    readonly actions: Array<Action>;
    readonly title: null | string;
    readonly description: null | string;
    readonly translations: Translations;
    static from(api: dialog.InteractiveMediaGroup): ActionGroup;
    static create({ actions, title, description, translations }: Props): ActionGroup;
    private constructor();
    toApi(): dialog.InteractiveMediaGroup;
}
export default ActionGroup;
