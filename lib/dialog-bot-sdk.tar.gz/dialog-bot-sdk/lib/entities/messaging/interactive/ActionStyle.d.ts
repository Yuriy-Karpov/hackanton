import { dialog } from '@dlghq/dialog-api';
export declare enum ActionStyle {
    DANGER = "danger",
    PRIMARY = "primary",
    DEFAULT = "default"
}
/**
 * @private
 */
export declare function apiToActionStyle(api: dialog.InteractiveMediaStyle): ActionStyle;
/**
 * @private
 */
export declare function actionStyleToApi(style: ActionStyle): dialog.InteractiveMediaStyle;
