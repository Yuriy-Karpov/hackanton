import { dialog } from '@dlghq/dialog-api';
import SelectOption from './SelectOption';
declare type Props = {
    label: string;
    options: Array<SelectOption>;
    defaultValue?: null | string;
};
declare class Select {
    readonly label: string;
    readonly options: Array<SelectOption>;
    readonly defaultValue: null | string;
    static from(api: dialog.InteractiveMediaSelect): Select;
    static create({ label, options, defaultValue }: Props): Select;
    private constructor();
    toApi(): dialog.InteractiveMediaWidget;
}
export default Select;
