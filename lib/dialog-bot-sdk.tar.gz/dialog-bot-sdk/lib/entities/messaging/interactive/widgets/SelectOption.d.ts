import { dialog } from '@dlghq/dialog-api';
declare type Props = {
    label: string;
    value?: string;
};
declare class SelectOption {
    readonly label: string;
    readonly value: string;
    static from(api: dialog.InteractiveMediaSelectOption): SelectOption;
    static create({ label, value }: Props): SelectOption;
    private constructor();
    toApi(): dialog.InteractiveMediaSelectOption;
}
export default SelectOption;
