import { dialog } from '@dlghq/dialog-api';
import { Widget } from './widgets';
import { ActionStyle } from './ActionStyle';
import ActionConfirm from './ActionConfirm';
declare type Props = {
    id: string;
    widget: Widget;
    style?: null | ActionStyle;
    confirm?: null | ActionConfirm;
};
declare class Action {
    readonly id: string;
    readonly widget: Widget;
    readonly style: ActionStyle;
    readonly confirm: null | ActionConfirm;
    static from(api: dialog.InteractiveMedia): Action | null;
    static create({ id, widget, style, confirm }: Props): Action;
    private constructor();
    toApi(): dialog.InteractiveMedia;
}
export default Action;
