import { dialog } from '@dlghq/dialog-api';
declare class DocumentVoiceExtension {
    readonly type = "voice";
    readonly duration: number;
    static from(api: dialog.DocumentExVoice): DocumentVoiceExtension;
    private constructor();
    toApi(): dialog.DocumentEx;
}
export default DocumentVoiceExtension;
