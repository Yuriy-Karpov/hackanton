import { dialog } from '@dlghq/dialog-api';
declare class DocumentPhotoExtension {
    readonly type = "photo";
    readonly width: number;
    readonly height: number;
    static from(api: dialog.DocumentExPhoto): DocumentPhotoExtension;
    static create(width: number, height: number): DocumentPhotoExtension;
    private constructor();
    toApi(): dialog.DocumentEx;
}
export default DocumentPhotoExtension;
