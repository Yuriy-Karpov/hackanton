import { dialog } from '@dlghq/dialog-api';
import DocumentPhotoExtension from './DocumentPhotoExtension';
import DocumentVideoExtension from './DocumentVideoExtension';
import DocumentVoiceExtension from './DocumentVoiceExtension';
export declare type DocumentExtension = DocumentPhotoExtension | DocumentVideoExtension | DocumentVoiceExtension;
export { DocumentPhotoExtension, DocumentVideoExtension, DocumentVoiceExtension };
/**
 * @private
 */
export declare function apiToDocumentExtension(api: dialog.DocumentEx): null | DocumentExtension;
