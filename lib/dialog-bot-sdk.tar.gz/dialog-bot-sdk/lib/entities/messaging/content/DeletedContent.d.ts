import { dialog } from '@dlghq/dialog-api';
declare class DeletedContent {
    readonly type = "deleted";
    static from(api: dialog.DeletedMessage): DeletedContent;
    static create(): DeletedContent;
    toApi(): dialog.MessageContent;
}
export default DeletedContent;
