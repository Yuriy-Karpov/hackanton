declare class UnknownContent {
    readonly type = "unknown";
    static create(): UnknownContent;
}
export default UnknownContent;
