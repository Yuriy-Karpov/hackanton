import { dialog } from '@dlghq/dialog-api';
import UUID from '../UUID';
declare enum MessageAttachmentType {
    REPLY = "reply",
    FORWARD = "forward"
}
declare class MessageAttachment {
    /**
     * Attachment type.
     */
    readonly type: MessageAttachmentType;
    /**
     * Attachment message identifiers.
     */
    readonly mids: Array<UUID>;
    static from(reply?: null | dialog.ReferencedMessages, forward?: null | dialog.ReferencedMessages): MessageAttachment | null;
    static reply(mids: UUID | Array<UUID>): MessageAttachment;
    static forward(mids: UUID | Array<UUID>): MessageAttachment;
    private constructor();
    toReplyApi(): null | dialog.ReferencedMessages;
    toForwardApi(): null | dialog.ReferencedMessages;
}
export default MessageAttachment;
