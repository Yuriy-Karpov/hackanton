import Long from 'long';
import Record from 'dataclass';
import { dialog } from '@dlghq/dialog-api';
import UserOutPeer from './UserOutPeer';
import Peer from '../Peer';
declare class User extends Record<User> {
    id: number;
    accessHash: Long;
    name: string;
    isBot: boolean;
    nick: null | string;
    static from(api: dialog.User): User;
    getPeer(): Peer;
    getUserOutPeer(): UserOutPeer;
}
export default User;
