import Long from 'long';
import { dialog } from '@dlghq/dialog-api';
import Peer from './Peer';
declare class OutPeer {
    readonly peer: Peer;
    readonly accessHash: Long;
    static from(api: dialog.OutPeer): OutPeer;
    static create(peer: Peer, accessHash: Long): OutPeer;
    private constructor();
    toApi(): dialog.OutPeer;
    toString(): string;
}
export default OutPeer;
