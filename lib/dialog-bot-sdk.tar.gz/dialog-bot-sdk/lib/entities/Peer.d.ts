import { dialog } from '@dlghq/dialog-api';
import PeerType from './PeerType';
declare class Peer {
    readonly id: number;
    readonly type: PeerType;
    readonly strId: null | string;
    static sip(strId: string): Peer;
    static private(id: number): Peer;
    static group(id: number): Peer;
    static from(api: dialog.Peer | dialog.OutPeer): Peer;
    protected constructor(id: number, type: PeerType, strId: string | null);
    getKey(): string;
    toString(): string;
}
export default Peer;
