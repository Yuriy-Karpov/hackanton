import { dialog } from '@dlghq/dialog-api/js';
declare enum PeerType {
    UNKNOWN = "unknown",
    PRIVATE = "private",
    GROUP = "group",
    SIP = "sip"
}
export declare function peerTypeToApi(type: PeerType): dialog.PeerType;
export default PeerType;
