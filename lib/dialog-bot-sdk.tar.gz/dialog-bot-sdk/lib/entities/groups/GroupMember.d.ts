import { dialog } from '@dlghq/dialog-api';
import Clock from '../Clock';
import GroupMemberPermission from './GroupMemberPermission';
declare class GroupMember {
    readonly clock: Clock;
    readonly userId: number;
    readonly invitedAt: Date;
    readonly deletedAt: Date | null;
    readonly permissions: Array<GroupMemberPermission>;
    static from(api: dialog.Member): GroupMember;
    constructor(api: dialog.Member);
}
export default GroupMember;
