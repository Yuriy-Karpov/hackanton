import { dialog } from '@dlghq/dialog-api';
import GroupMember from './GroupMember';
declare class GroupMemberList {
    readonly items: Array<GroupMember>;
    readonly isLoaded: boolean;
    static from(api: dialog.Group): GroupMemberList;
    static create(items: Array<GroupMember>): GroupMemberList;
    constructor(items: Array<GroupMember>, isLoaded: boolean);
}
export default GroupMemberList;
