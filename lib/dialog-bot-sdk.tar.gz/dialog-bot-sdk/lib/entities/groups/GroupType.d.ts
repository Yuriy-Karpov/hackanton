import { dialog } from '@dlghq/dialog-api';
export declare abstract class GroupType {
    static privateGroup(): PrivateGroupType;
    static publicGroup(shortname: string): PublicGroupType;
    static privateChannel(): PrivateChannelType;
    static publicChannel(shortname: string): PublicChannelType;
    static from(api: dialog.GroupData): PrivateGroupType | PublicGroupType | PrivateChannelType | PublicChannelType | UnknownGroupType;
    toApi(): {
        type: dialog.GroupType;
        shortname: string;
    } | {
        type: dialog.GroupType;
        shortname?: undefined;
    };
}
export declare class PublicGroupType extends GroupType {
    readonly shortname: string;
    constructor(shortname: string);
}
export declare class PrivateGroupType extends GroupType {
}
export declare class PublicChannelType extends GroupType {
    readonly shortname: string;
    constructor(shortname: string);
}
export declare class PrivateChannelType extends GroupType {
}
export declare class UnknownGroupType extends GroupType {
}
