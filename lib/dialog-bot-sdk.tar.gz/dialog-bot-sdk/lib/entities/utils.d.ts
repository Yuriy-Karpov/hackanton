import Long from 'long';
import { google } from '@dlghq/dialog-api';
interface ProtoValue<T> {
    value?: null | T;
}
export declare function getOpt<T, R>(value: undefined | null | ProtoValue<T>, defaultValue: R): T | R;
export declare function mapOpt<T, R>(value: undefined | null | ProtoValue<T>, mapper: (value: T) => R, defaultValue: R): R;
export declare function dateFromLong(time?: Long): Date;
export declare function dateFromTimestamp(ts?: google.protobuf.Timestamp | null): Date;
export declare function longFromDate(date?: Date | null): Long;
export {};
