declare function normalizeArray<T>(value: undefined | null | T | Array<T>): Array<T>;
export default normalizeArray;
