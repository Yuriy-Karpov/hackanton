declare function reduce<T, R>(array: Array<T>, initialState: R, reducer: (state: R, value: T) => R): R;
export default reduce;
