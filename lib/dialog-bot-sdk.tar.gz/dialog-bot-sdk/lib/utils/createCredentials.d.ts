/// <reference types="node" />
/// <reference types="grpc" />
export declare type SSLConfig = {
    rootCerts?: Buffer;
    privateKey?: Buffer;
    certChain?: Buffer;
};
declare function createCredentials(url: URL, ssl: SSLConfig | void): import("grpc").ChannelCredentials;
export default createCredentials;
