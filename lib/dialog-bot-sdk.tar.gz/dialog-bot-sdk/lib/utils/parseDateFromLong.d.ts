import Long from 'long';
declare function parseDateFromLong(date: Long): Date;
export default parseDateFromLong;
