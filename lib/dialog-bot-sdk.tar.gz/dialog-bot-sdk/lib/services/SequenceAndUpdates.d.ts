import { Metadata } from 'grpc';
import { dialog, google } from '@dlghq/dialog-api';
import { Observable } from 'rxjs';
import Service, { Config } from './Service';
declare class SequenceAndUpdates extends Service<any> {
    private readonly config;
    constructor(config: Config);
    getState(request: dialog.RequestGetState, metadata?: Metadata): Promise<dialog.ResponseSeq>;
    getDifference(request: dialog.RequestGetDifference, metadata?: Metadata): Promise<dialog.ResponseGetDifference>;
    getReferencedEntities(request: dialog.RequestGetReferencedEntitites, metadata?: Metadata): Promise<dialog.ResponseGetReferencedEntitites>;
    seqUpdates(request: google.protobuf.Empty): Observable<dialog.SeqUpdateBox>;
}
export default SequenceAndUpdates;
