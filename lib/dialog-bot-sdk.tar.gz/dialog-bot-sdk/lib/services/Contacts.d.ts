import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Contacts extends Service<any> {
    constructor(config: Config);
    searchContacts(request: dialog.RequestSearchContacts, metadata?: Metadata): Promise<dialog.ResponseSearchContacts>;
}
export default Contacts;
