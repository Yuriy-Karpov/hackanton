import { Logger } from 'pino';
import { InterceptingCall, CallOptions } from 'grpc';
declare function createLogInterceptor(logger: Logger): (options: CallOptions, nextCall: (options: CallOptions) => InterceptingCall) => InterceptingCall;
export default createLogInterceptor;
