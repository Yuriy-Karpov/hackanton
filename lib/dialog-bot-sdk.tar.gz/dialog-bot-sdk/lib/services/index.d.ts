import { Config } from './Service';
import Users from './Users';
import Groups from './Groups';
import Search from './Search';
import Contacts from './Contacts';
import Messaging from './Messaging';
import Parameters from './Parameters';
import Registration from './Registration';
import MediaAndFiles from './MediaAndFiles';
import Authentication from './Authentication';
import SequenceAndUpdates from './SequenceAndUpdates';
declare class Services {
    readonly users: Users;
    readonly groups: Groups;
    readonly search: Search;
    readonly contacts: Contacts;
    readonly messaging: Messaging;
    readonly parameters: Parameters;
    readonly registration: Registration;
    readonly mediaAndFiles: MediaAndFiles;
    readonly authentication: Authentication;
    readonly sequenceAndUpdates: SequenceAndUpdates;
    constructor(config: Config);
    close(): void;
}
export default Services;
