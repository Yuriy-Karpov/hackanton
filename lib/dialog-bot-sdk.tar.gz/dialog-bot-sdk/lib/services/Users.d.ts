import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Users extends Service<any> {
    constructor(config: Config);
    loadFullUsers(request: dialog.RequestLoadFullUsers, metadata?: Metadata): Promise<dialog.ResponseLoadFullUsers>;
}
export default Users;
