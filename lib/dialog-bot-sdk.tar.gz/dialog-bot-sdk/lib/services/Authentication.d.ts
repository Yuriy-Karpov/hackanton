import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Authentication extends Service<any> {
    constructor(config: Config);
    startTokenAuth(request: dialog.RequestStartTokenAuth, metadata?: Metadata): Promise<dialog.ResponseAuth>;
    startUsernameAuth(request: dialog.RequestStartUsernameAuth, metadata?: Metadata): Promise<dialog.ResponseStartUsernameAuth>;
    validatePassword(request: dialog.RequestValidatePassword, metadata?: Metadata): Promise<dialog.ResponseAuth>;
}
export default Authentication;
