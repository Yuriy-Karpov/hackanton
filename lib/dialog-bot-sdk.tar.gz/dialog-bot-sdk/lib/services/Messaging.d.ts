import { Metadata } from 'grpc';
import { dialog } from '@dlghq/dialog-api';
import Service, { Config } from './Service';
declare class Messaging extends Service<any> {
    constructor(config: Config);
    fetchDialogIndex(request: dialog.RequestFetchDialogIndex, metadata?: Metadata): Promise<dialog.ResponseFetchDialogIndex>;
    loadDialogs(request: dialog.RequestLoadDialogs, metadata?: Metadata): Promise<dialog.ResponseLoadDialogs>;
    sendMessage(request: dialog.RequestSendMessage, metadata?: Metadata): Promise<dialog.ResponseSendMessage>;
    updateMessage(request: dialog.RequestUpdateMessage, metadata?: Metadata): Promise<dialog.ResponseSeqDate>;
    loadHistory(request: dialog.RequestLoadHistory, metadata?: Metadata): Promise<dialog.ResponseLoadHistory>;
    readMessage(request: dialog.RequestMessageRead, metadata?: Metadata): Promise<void>;
}
export default Messaging;
